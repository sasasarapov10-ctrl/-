(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.EnamelModel = api;
}(typeof window !== 'undefined' ? window : null, function () {
  'use strict';

  // An illustrative pH recovery model, not a measurement of enamel loss.
  var defaults = Object.freeze({
    baseline: 6.8,
    minPH: 4.2,
    tau: 12,
    threshold: 5.5,
    duration: 60,
    eventTimes: Object.freeze([0]),
    step: 0.25
  });

  function validate(config) {
    if (config === undefined) config = {};
    if (!config || typeof config !== 'object' || Array.isArray(config)) {
      throw new TypeError('Model settings must be an object.');
    }
    var result = {};
    ['baseline', 'minPH', 'tau', 'threshold', 'duration', 'step'].forEach(function (key) {
      var value = config[key] === undefined ? defaults[key] : config[key];
      if (typeof value !== 'number' || !Number.isFinite(value)) {
        throw new TypeError(key + ' must be a finite number.');
      }
      result[key] = value;
    });
    ['baseline', 'minPH', 'threshold'].forEach(function (key) {
      if (result[key] < 0 || result[key] > 14) {
        throw new RangeError(key + ' must be between 0 and 14.');
      }
    });
    if (result.minPH > result.baseline) {
      throw new RangeError('minPH must not exceed baseline.');
    }
    if (result.tau <= 0) throw new RangeError('tau must be greater than zero.');
    if (result.duration < 0) throw new RangeError('duration must be nonnegative.');
    if (result.step <= 0) throw new RangeError('step must be greater than zero.');
    if (result.duration / result.step > 200000) {
      throw new RangeError('Increase step: the graph may contain at most 200000 regular samples.');
    }
    var events = config.eventTimes === undefined ? defaults.eventTimes : config.eventTimes;
    if (!Array.isArray(events) || events.length === 0 || events[0] !== 0) {
      throw new RangeError('eventTimes must be a nonempty array starting at zero.');
    }
    if (events.length > 10000) throw new RangeError('Too many events (maximum 10000).');
    result.eventTimes = events.map(function (time, index) {
      if (typeof time !== 'number' || !Number.isFinite(time) || time < 0 || time > result.duration) {
        throw new RangeError('Each event time must be a finite number within the observation period.');
      }
      if (index > 0 && time <= events[index - 1]) {
        throw new RangeError('Event times must be strictly increasing.');
      }
      return time;
    });
    return result;
  }

  function recover(elapsed, parameters) {
    return parameters.baseline - (parameters.baseline - parameters.minPH) *
      Math.exp(-elapsed / parameters.tau);
  }

  function valueAt(time, parameters, events) {
    var low = 0;
    var high = events.length - 1;
    while (low < high) {
      var middle = Math.ceil((low + high) / 2);
      if (events[middle] <= time) low = middle;
      else high = middle - 1;
    }
    return recover(time - events[low], parameters);
  }

  // Right-continuous: a value exactly at an event includes the new pH drop.
  function phAt(time, parameters, eventTimes) {
    var config = Object.assign({}, parameters || {});
    if (eventTimes !== undefined) config.eventTimes = eventTimes;
    config = validate(config);
    if (typeof time !== 'number' || !Number.isFinite(time) || time < 0 || time > config.duration) {
      throw new RangeError('time must be within the observation period.');
    }
    return valueAt(time, config, config.eventTimes);
  }

  // Exact integral on one interval between events. No graph sampling is used.
  function intervalMetrics(length, parameters) {
    var baseline = parameters.baseline;
    var minimum = parameters.minPH;
    var threshold = parameters.threshold;
    var amplitude = baseline - minimum;
    if (length === 0 || minimum >= threshold) return { timeBelow: 0, deficitArea: 0 };
    if (amplitude === 0) {
      return { timeBelow: length, deficitArea: (threshold - baseline) * length };
    }
    var below = length;
    if (threshold < baseline) {
      var crossing = parameters.tau * Math.log(amplitude / (baseline - threshold));
      below = Math.min(length, crossing);
    }
    var area = (threshold - baseline) * below +
      amplitude * parameters.tau * -Math.expm1(-below / parameters.tau);
    return { timeBelow: below, deficitArea: Math.max(0, area) };
  }

  function simulate(settings) {
    var config = validate(settings);
    var events = config.eventTimes;
    var parameters = {};
    ['baseline', 'minPH', 'tau', 'threshold', 'duration', 'step'].forEach(function (key) {
      parameters[key] = config[key];
    });
    var timeBelow = 0;
    var deficitArea = 0;
    events.forEach(function (time, index) {
      var end = index + 1 < events.length ? events[index + 1] : config.duration;
      var interval = intervalMetrics(end - time, config);
      timeBelow += interval.timeBelow;
      deficitArea += interval.deficitArea;
    });

    var times = new Set([0, config.duration]);
    for (var sample = 1; sample * config.step < config.duration; sample += 1) {
      times.add(sample * config.step);
    }
    events.forEach(function (time) { times.add(time); });
    var eventSet = new Set(events);
    var points = [];
    var previousEvent = null;
    Array.from(times).sort(function (a, b) { return a - b; }).forEach(function (time) {
      if (eventSet.has(time)) {
        // Both limits preserve a vertical drop instead of a diagonal graph segment.
        points.push({ time: time, ph: previousEvent === null ? config.baseline : recover(time - previousEvent, config) });
        points.push({ time: time, ph: config.minPH });
        previousEvent = time;
      } else {
        points.push({ time: time, ph: recover(time - previousEvent, config) });
      }
    });

    return {
      points: points,
      metrics: {
        timeBelow: timeBelow,
        deficitArea: deficitArea,
        minPH: config.minPH,
        finalPH: valueAt(config.duration, config, events)
      },
      parameters: parameters,
      eventTimes: events.slice()
    };
  }

  return Object.freeze({ defaults: defaults, validate: validate, phAt: phAt, simulate: simulate });
}));
