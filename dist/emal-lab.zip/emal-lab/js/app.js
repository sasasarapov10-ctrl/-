(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const model = window.EnamelModel;
  const format = (number, digits = 1) => new Intl.NumberFormat('uk-UA', {
    minimumFractionDigits: digits, maximumFractionDigits: digits,
  }).format(number);
  const PLAY_ICON = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M5 3.5 12 8l-7 4.5Z" fill="currentColor"/></svg>';
  const PAUSE_ICON = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 3h3v10H4zm5 0h3v10H9z" fill="currentColor"/></svg>';
  const controls = ['min-ph', 'tau', 'episodes', 'interval', 'threshold'];
  const presets = {
    single: { minPH: 4.2, tau: 12, episodes: 1, interval: 8, threshold: 5.5 },
    repeated: { minPH: 4.2, tau: 12, episodes: 3, interval: 8, threshold: 5.5 },
    water: { minPH: 6.8, tau: 12, episodes: 1, interval: 8, threshold: 5.5 },
  };
  let current, comparison, viewer, animation = null, previousFrame = null;
  let graphDimensions, dragging = false, playbackTime = 0;

  function settings() {
    const count = Number($('episodes').value);
    const interval = Math.min(10, Math.max(2, Math.round(Number($('interval').value) || 8)));
    $('interval').value = interval;
    return {
      baseline: 6.8, minPH: Number($('min-ph').value), tau: Number($('tau').value),
      threshold: Number($('threshold').value), duration: 60,
      eventTimes: Array.from({ length: count }, (_, index) => index * interval), step: 0.25,
    };
  }

  function paintRange(element) {
    const progress = (Number(element.value) - Number(element.min)) / (Number(element.max) - Number(element.min)) * 100;
    element.style.setProperty('--progress', `${progress}%`);
  }

  function phAt(time, simulation = current) {
    return model.phAt(time, simulation.parameters, simulation.eventTimes);
  }

  function stop() {
    if (animation !== null) cancelAnimationFrame(animation);
    animation = null;
    previousFrame = null;
    $('play').innerHTML = PLAY_ICON;
    $('play').setAttribute('aria-label', 'Відтворити зміни pH');
    $('play').setAttribute('aria-pressed', 'false');
  }

  function selectPreset(name) {
    const preset = presets[name];
    stop();
    $('min-ph').value = preset.minPH;
    $('tau').value = preset.tau;
    $('episodes').value = preset.episodes;
    $('interval').value = preset.interval;
    $('threshold').value = preset.threshold;
    $('time').value = 0;
    update();
  }

  function update() {
    const config = settings();
    current = model.simulate(config);
    comparison = model.simulate({ ...config, eventTimes: [0] });
    $('min-ph-value').textContent = format(config.minPH);
    $('tau-value').textContent = `${format(config.tau, 0)} хв`;
    $('threshold-value').textContent = format(config.threshold);
    $('interval').disabled = config.eventTimes.length === 1;
    document.querySelectorAll('[data-preset]').forEach(button => {
      const p = presets[button.dataset.preset];
      const active = p.minPH === config.minPH && p.tau === config.tau &&
        p.episodes === config.eventTimes.length && p.threshold === config.threshold &&
        (p.episodes === 1 || p.interval === Number($('interval').value));
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    $('below-value').textContent = format(current.metrics.timeBelow, 2);
    $('minimum-value').textContent = format(current.metrics.minPH, 1);
    $('deficit-value').textContent = format(current.metrics.deficitArea, 2);
    $('below-compare').textContent = `Один епізод: ${format(comparison.metrics.timeBelow, 2)} хв за 60 хв.`;
    const difference = current.metrics.timeBelow - comparison.metrics.timeBelow;
    let observation;
    if (config.minPH >= config.threshold) {
      observation = `За цих умов крива не опускається нижче pH ${format(config.threshold)}. Обидва інтегральні показники дорівнюють нулю.`;
    } else if (config.eventTimes.length === 1) {
      observation = `Один епізод: ${format(current.metrics.timeBelow, 2)} хв нижче pH ${format(config.threshold)}. Додайте епізоди, щоб порівняти частоту впливу.`;
    } else {
      const eventWord = config.eventTimes.length < 5 ? 'епізоди' : 'епізодів';
      observation = `${config.eventTimes.length} ${eventWord} за однакової глибини спаду: на ${format(difference, 2)} хв довше нижче порога, ніж після одного епізоду.`;
    }
    $('chart-observation').textContent = observation;
    $('data-table').replaceChildren();
    for (let time = 0; time <= 60; time += 5) {
      const row = document.createElement('tr');
      [format(time, 0), format(phAt(time), 3), format(phAt(time, comparison), 3)].forEach(text => {
        const cell = document.createElement('td');
        cell.textContent = text;
        row.append(cell);
      });
      $('data-table').append(row);
    }
    document.querySelectorAll('input[type="range"]').forEach(paintRange);
    drawChart();
    updateTime();
  }

  function drawChart() {
    if (!current) return;
    const svg = $('chart');
    const width = Math.max(310, Math.round(svg.getBoundingClientRect().width));
    const height = width < 600 ? 275 : 315;
    const margin = { left: 40, right: 22, top: 31, bottom: 44 };
    const plotWidth = width - margin.left - margin.right;
    const plotHeight = height - margin.top - margin.bottom;
    const xmin = 0, xmax = 60, ymin = 2.8, ymax = 7.2;
    const x = time => margin.left + (time - xmin) / (xmax - xmin) * plotWidth;
    const y = ph => margin.top + (ymax - ph) / (ymax - ymin) * plotHeight;
    const threshold = current.parameters.threshold;
    const line = points => points.map((point, index) => `${index ? 'L' : 'M'}${x(point.time).toFixed(3)},${y(point.ph).toFixed(3)}`).join(' ');
    const comparisonVisible = $('compare').checked;
    $('compare-legend').hidden = !comparisonVisible;
    graphDimensions = { x, y, width, height, margin, plotWidth, plotHeight };
    svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
    const parts = [
      '<title id="chart-title">Відновлення модельного pH протягом 60 хвилин</title>',
      `<desc id="chart-description">Кількість епізодів: ${current.eventTimes.length}; мінімальний pH ${format(current.metrics.minPH)}; час нижче порога ${format(current.metrics.timeBelow, 2)} хв. Точні значення доступні в таблиці під графіком.</desc>`,
      `<defs><clipPath id="below-clip"><rect x="${x(0)}" y="${y(threshold)}" width="${plotWidth}" height="${y(ymin) - y(threshold)}"/></clipPath><clipPath id="plot-clip"><rect x="${x(0)}" y="${margin.top}" width="${plotWidth}" height="${plotHeight}"/></clipPath></defs>`,
    ];
    for (let ph = 3; ph <= 7; ph++) {
      parts.push(`<line x1="${x(0)}" x2="${x(60)}" y1="${y(ph)}" y2="${y(ph)}" stroke="#e5e9df"/><text x="${x(0) - 13}" y="${y(ph) + 4}" text-anchor="end">${ph}</text>`);
    }
    for (let time = 0; time <= 60; time += 10) {
      parts.push(`<text x="${x(time)}" y="${height - 24}" text-anchor="middle">${time}</text>`);
    }
    current.eventTimes.forEach(time => parts.push(`<line x1="${x(time)}" x2="${x(time)}" y1="${margin.top}" y2="${y(ymin)}" stroke="#dce4d9" stroke-dasharray="2 5"/><circle cx="${x(time)}" cy="${margin.top - 8}" r="3" fill="#7c9b85"/>`));
    parts.push(`<text x="${x(0)}" y="13">Модельний pH</text><text x="${width / 2}" y="${height - 2}" text-anchor="middle">Час, хв</text>`);
    parts.push(`<path d="M${x(0)},${y(threshold)} ${line(current.points).replace(/^M/, 'L')} L${x(60)},${y(threshold)} Z" fill="#ead9bd" opacity="0.7" clip-path="url(#below-clip)"/>`);
    parts.push(`<line x1="${x(0)}" x2="${x(60)}" y1="${y(threshold)}" y2="${y(threshold)}" stroke="#bb825d" stroke-width="1.3" stroke-dasharray="5 5"/>`);
    if (comparisonVisible) parts.push(`<path d="${line(comparison.points)}" fill="none" stroke="#a6b3b5" stroke-width="2" stroke-dasharray="6 5" clip-path="url(#plot-clip)"/>`);
    parts.push(`<path d="${line(current.points)}" fill="none" stroke="#28665c" stroke-width="2.5" stroke-linejoin="round" clip-path="url(#plot-clip)"/>`);
    parts.push('<g id="time-marker" aria-hidden="true"><line stroke="#577c70" stroke-width="1" stroke-dasharray="3 4"/><circle r="5" fill="#28665c" stroke="#fffefa" stroke-width="2"/></g>');
    svg.innerHTML = parts.join('');
    updateMarker();
  }

  function updateMarker() {
    if (!current || !graphDimensions) return;
    const time = Number($('time').value);
    const { x, y, margin, plotHeight } = graphDimensions;
    const marker = $('time-marker');
    if (!marker) return;
    const line = marker.querySelector('line');
    line.setAttribute('x1', x(time)); line.setAttribute('x2', x(time));
    line.setAttribute('y1', margin.top); line.setAttribute('y2', margin.top + plotHeight);
    const circle = marker.querySelector('circle');
    circle.setAttribute('cx', x(time)); circle.setAttribute('cy', y(phAt(time)));
  }

  function updateTime() {
    if (!current) return;
    const time = Number($('time').value);
    const ph = phAt(time);
    $('time-value').textContent = `${format(time, time % 1 ? 1 : 0)} хв`;
    $('ph-now').textContent = format(ph, 2);
    $('surface-state').textContent = ph < current.parameters.threshold ? 'Середовище нижче порога' : 'Середовище на рівні або вище порога';
    document.querySelector('.live-dot').style.background = ph < current.parameters.threshold ? '#c87952' : '#649784';
    paintRange($('time'));
    if (viewer) viewer.setPH(ph, current.parameters.threshold);
    updateMarker();
  }

  function tick(now) {
    if (previousFrame === null) previousFrame = now;
    // Playback compresses 60 model minutes into 15 real seconds.
    const next = Math.min(60, playbackTime + (now - previousFrame) * 0.004);
    playbackTime = next;
    previousFrame = now;
    $('time').value = next;
    updateTime();
    if (next >= 60) stop();
    else animation = requestAnimationFrame(tick);
  }

  controls.forEach(id => $(id).addEventListener('input', () => { stop(); update(); }));
  $('controls').addEventListener('submit', event => event.preventDefault());
  document.querySelectorAll('[data-preset]').forEach(button => button.addEventListener('click', () => selectPreset(button.dataset.preset)));
  $('reset').addEventListener('click', () => { selectPreset('repeated'); $('compare').checked = true; drawChart(); if (viewer) viewer.reset(); });
  $('reset-view').addEventListener('click', () => { if (viewer) viewer.reset(); });
  $('time').addEventListener('input', () => { stop(); updateTime(); });
  $('compare').addEventListener('change', drawChart);
  $('play').addEventListener('click', () => {
    if (animation !== null) return stop();
    if (Number($('time').value) >= 60) $('time').value = 0;
    playbackTime = Number($('time').value);
    $('play').innerHTML = PAUSE_ICON;
    $('play').setAttribute('aria-label', 'Призупинити зміни pH');
    $('play').setAttribute('aria-pressed', 'true');
    animation = requestAnimationFrame(tick);
  });
  document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); });

  function selectChartTime(event) {
    const { margin, plotWidth, width } = graphDimensions;
    const bounds = $('chart').getBoundingClientRect();
    const position = (event.clientX - bounds.left) / bounds.width * width;
    $('time').value = Math.max(0, Math.min(60, (position - margin.left) / plotWidth * 60));
    stop(); updateTime();
  }
  $('chart').style.cursor = 'crosshair';
  $('chart').addEventListener('pointerdown', event => {
    if (event.button !== 0) return;
    dragging = true; $('chart').setPointerCapture(event.pointerId); selectChartTime(event);
  });
  $('chart').addEventListener('pointermove', event => { if (dragging) selectChartTime(event); });
  for (const name of ['pointerup', 'pointercancel', 'lostpointercapture']) $('chart').addEventListener(name, () => { dragging = false; });

  $('download-csv').addEventListener('click', () => {
    const p = current.parameters;
    const rows = [
      '# Навчальна модель; не лабораторні вимірювання і не прогноз втрати емалі',
      '# pH(t)=baseline-(baseline-minPH)*exp(-(t-lastEvent)/tau)',
      `# baseline=${p.baseline};minPH=${p.minPH};tau_min=${p.tau};threshold=${p.threshold};duration_min=${p.duration}`,
      `# event_times_min=${current.eventTimes.join('|')}`,
      `# time_below_min=${current.metrics.timeBelow};deficit_pH_min=${current.metrics.deficitArea}`,
      '# У момент епізоду pH наведено після спаду; одиниці дефіциту pH*min не є дозою кислоти',
      'time_min;pH_scenario;pH_single_episode;threshold',
    ];
    for (let i = 0; i <= 240; i++) {
      const time = i / 4;
      rows.push([time.toFixed(2), phAt(time).toFixed(6), phAt(time, comparison).toFixed(6), p.threshold.toFixed(2)].join(';'));
    }
    const url = URL.createObjectURL(new Blob(['\uFEFF', rows.join('\r\n')], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = url; link.download = 'emal-scenario.csv';
    document.body.append(link); link.click(); link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  });

  try {
    viewer = new window.EnamelViewer({ canvas: $('tooth-canvas') });
    if (viewer.mode === '2d') {
      $('render-mode').textContent = 'Схема · 2D';
      $('rotate-hint').hidden = true;
      $('reset-view').hidden = true;
    }
    $('tooth-canvas').addEventListener('webglcontextlost', () => {
      $('render-mode').textContent = 'Схема · 2D';
      $('rotate-hint').hidden = true;
      $('reset-view').hidden = true;
    });
  } catch (error) {
    $('render-mode').textContent = 'Схематичний розріз';
    $('surface-state').textContent = '3D недоступне у цьому браузері';
  }
  new ResizeObserver(() => drawChart()).observe(document.querySelector('.chart-wrap'));
  update();
}());
