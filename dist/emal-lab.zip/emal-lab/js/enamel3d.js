/* Local educational tooth section. The pH indicator never changes tissue geometry. */
(function (global) {
  'use strict';

  const BODY = [
    ['M', -.48, 1.13], ['C', -.86, 1.22, -1.03, .90, -.94, .45],
    ['C', -.91, .17, -.76, -.06, -.65, -.30],
    ['C', -.63, -.70, -.77, -1.37, -.57, -1.69],
    ['C', -.46, -1.88, -.35, -1.52, -.27, -1.21],
    ['C', -.18, -.85, -.10, -.62, -.01, -.55],
    ['C', .14, -.63, .20, -.97, .34, -1.30],
    ['C', .49, -1.67, .64, -1.86, .73, -1.57],
    ['C', .82, -1.20, .61, -.65, .65, -.31],
    ['C', .77, -.04, .92, .17, .96, .52],
    ['C', 1.04, .98, .85, 1.23, .55, 1.16],
    ['C', .35, 1.35, .18, 1.23, .04, 1.09],
    ['C', -.12, 1.00, -.24, 1.24, -.48, 1.13], ['Z']
  ];
  const ENAMEL = [
    ['M', -.48, 1.23], ['C', -.88, 1.34, -1.09, 1.00, -1.02, .53],
    ['C', -.98, .23, -.83, -.02, -.68, -.18],
    ['C', -.36, -.12, .33, -.14, .70, -.18],
    ['C', .86, -.01, 1.00, .25, 1.03, .56],
    ['C', 1.09, 1.00, .88, 1.34, .56, 1.26],
    ['C', .35, 1.43, .17, 1.34, .02, 1.18],
    ['C', -.12, 1.09, -.26, 1.35, -.48, 1.23], ['Z']
  ];
  const DENTIN = [
    ['M', -.47, 1.04], ['C', -.74, 1.12, -.90, .84, -.82, .49],
    ['C', -.78, .21, -.65, -.04, -.56, -.29],
    ['C', -.54, -.69, -.68, -1.29, -.54, -1.59],
    ['C', -.46, -1.60, -.39, -1.30, -.31, -1.05],
    ['C', -.20, -.72, -.11, -.49, -.01, -.46],
    ['C', .16, -.49, .28, -.98, .40, -1.25],
    ['C', .50, -1.49, .60, -1.68, .64, -1.48],
    ['C', .69, -1.16, .49, -.66, .55, -.28],
    ['C', .66, -.02, .81, .22, .84, .52],
    ['C', .89, .87, .74, 1.10, .52, 1.04],
    ['C', .32, 1.21, .20, 1.14, .06, .99],
    ['C', -.10, .92, -.27, 1.15, -.47, 1.04], ['Z']
  ];
  const PULP = [
    ['M', -.44, .61], ['C', -.44, .82, -.29, .86, -.24, .58],
    ['C', -.20, .42, -.11, .43, -.08, .60],
    ['C', -.02, .83, .12, .84, .18, .58],
    ['C', .22, .41, .29, .50, .36, .67],
    ['C', .45, .87, .56, .71, .49, .47],
    ['C', .46, .20, .34, .07, .26, -.03],
    ['C', .18, -.14, .17, -.30, .20, -.47],
    ['C', .25, -.75, .48, -1.22, .54, -1.46],
    ['C', .45, -1.30, .25, -.92, .10, -.68],
    ['C', .03, -.57, -.04, -.60, -.11, -.75],
    ['C', -.25, -1.06, -.40, -1.43, -.48, -1.53],
    ['C', -.44, -1.25, -.32, -.88, -.28, -.49],
    ['C', -.26, -.23, -.32, -.04, -.43, .13],
    ['C', -.54, .35, -.48, .48, -.44, .61], ['Z']
  ];

  function trace(target, commands) {
    commands.forEach(function (c) {
      if (c[0] === 'M') target.moveTo(c[1], c[2]);
      else if (c[0] === 'C') target.bezierCurveTo(c[1], c[2], c[3], c[4], c[5], c[6]);
      else if (c[0] === 'L') target.lineTo(c[1], c[2]);
      else target.closePath();
    });
    return target;
  }

  class EnamelViewer {
    constructor(options) {
      if (!options || !options.canvas || typeof options.canvas.getContext !== 'function') {
        throw new TypeError('EnamelViewer: pass a canvas element.');
      }
      this.canvas = options.canvas;
      this.fallback = options.fallback || null;
      this.ph = 7;
      this.threshold = 5.5;
      this.yaw = -.30;
      this.pitch = -.06;
      this.zoom = 1;
      this.pointer = null;
      this.destroyed = false;
      this.listeners = [];
      this.resources = [];
      this.frame = 0;
      this.reducedMotion = !!(global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches);
      this.originalTouchAction = this.canvas.style.touchAction;
      this.originalOpacity = this.canvas.style.opacity;
      this.canvas.style.touchAction = 'none';
      if (!this.canvas.hasAttribute('aria-label')) {
        this.canvas.setAttribute('aria-label', 'Навчальний розріз зуба: емаль, дентин і пульпа. Перетягніть для обертання.');
      }
      this.canvas.setAttribute('role', 'img');
      if (!this.canvas.hasAttribute('tabindex')) this.canvas.tabIndex = 0;
      this.mode = '2d';
      if (global.THREE) {
        try {
          this.setup3D();
          this.mode = '3d';
        } catch (error) {
          if (this.renderer) this.renderer.dispose();
          this.renderer = null;
        }
      }
      if (this.mode !== '3d') this.setupFallback();
      if (this.fallback) this.fallback.hidden = this.mode === '3d';
      this.bindEvents();
      if (global.ResizeObserver) {
        this.observer = new ResizeObserver(() => this.resize());
        this.observer.observe(this.canvas);
      } else {
        this.listen(global, 'resize', () => this.resize());
      }
      this.resize();
      this.setPH(this.ph, this.threshold);
    }

    keep(resource) {
      this.resources.push(resource);
      return resource;
    }

    shape(commands) {
      return trace(new global.THREE.Shape(), commands);
    }

    setup3D() {
      const T = global.THREE;
      this.renderer = new T.WebGLRenderer({ canvas: this.canvas, alpha: true, antialias: true, powerPreference: 'low-power' });
      this.renderer.setClearColor(0x000000, 0);
      this.renderer.setPixelRatio(Math.min(global.devicePixelRatio || 1, 2));
      this.renderer.outputColorSpace = T.SRGBColorSpace;
      this.renderer.toneMapping = T.ACESFilmicToneMapping;
      this.renderer.toneMappingExposure = 1.04;
      this.scene = new T.Scene();
      this.camera = new T.PerspectiveCamera(32, 1, .1, 40);
      this.camera.position.set(.15, .16, 7.5);
      this.camera.lookAt(0, -.14, 0);
      this.stage = new T.Group();
      this.stage.position.y = -.04;
      this.scene.add(this.stage);
      this.model = new T.Group();
      this.stage.add(this.model);
      this.scene.add(new T.HemisphereLight(0xfffbef, 0x8a978c, 1.5));
      const key = new T.DirectionalLight(0xfff8e8, 2.7);
      key.position.set(-3.5, 4.5, 6);
      this.scene.add(key);
      const fill = new T.DirectionalLight(0xdce9ef, .8);
      fill.position.set(4, 1, -2);
      this.scene.add(fill);
      const edge = new T.DirectionalLight(0xffffff, .5);
      edge.position.set(-1, -2, 3);
      this.scene.add(edge);

      const enamel = this.keep(new T.MeshPhysicalMaterial({ color: 0xf5f1df, roughness: .24, metalness: 0, clearcoat: .5, clearcoatRoughness: .24 }));
      const cementum = this.keep(new T.MeshStandardMaterial({ color: 0xc8b38e, roughness: .76, metalness: 0 }));
      const dentin = this.keep(new T.MeshStandardMaterial({ color: 0xdab983, roughness: .62, metalness: 0, side: T.DoubleSide }));
      const pulp = this.keep(new T.MeshStandardMaterial({ color: 0xbd777a, roughness: .67, metalness: 0, side: T.DoubleSide }));
      const bodyGeometry = this.keep(new T.ExtrudeGeometry(this.shape(BODY), { depth: .64, steps: 1, curveSegments: 36, bevelEnabled: true, bevelThickness: .045, bevelSize: .055, bevelSegments: 6 }));
      bodyGeometry.translate(0, 0, -.64);
      const body = new T.Mesh(bodyGeometry, cementum);
      body.position.z = -.012; // Separate overlapping crown caps to avoid z-fighting.
      this.model.add(body);
      const enamelGeometry = this.keep(new T.ExtrudeGeometry(this.shape(ENAMEL), { depth: .70, steps: 1, curveSegments: 40, bevelEnabled: true, bevelThickness: .045, bevelSize: .055, bevelSegments: 6 }));
      enamelGeometry.translate(0, 0, -.70);
      this.model.add(new T.Mesh(enamelGeometry, enamel));
      const sectionGeometry = this.keep(new T.ShapeGeometry(this.shape(DENTIN), 40));
      const section = new T.Mesh(sectionGeometry, dentin);
      section.position.z = .047;
      this.model.add(section);
      const pulpGeometry = this.keep(new T.ShapeGeometry(this.shape(PULP), 36));
      const chamber = new T.Mesh(pulpGeometry, pulp);
      chamber.position.z = .052;
      this.model.add(chamber);

      // Only the outside wall receives the environmental indicator. The cut face
      // and all anatomical dimensions stay identical at every pH value.
      const invisibleFace = this.keep(new T.MeshBasicMaterial({ visible: false }));
      this.indicatorMaterial = this.keep(new T.MeshStandardMaterial({ color: 0x7faaa1, roughness: .44, transparent: true, opacity: .11, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 }));
      const indicator = new T.Mesh(enamelGeometry, [invisibleFace, this.indicatorMaterial]);
      indicator.scale.set(1.003, 1.003, 1.003);
      indicator.position.z = .001;
      this.model.add(indicator);

      // A few understated dentinal lines indicate tissue structure, not measured
      // microscopic detail or simulated enamel damage.
      const lineMaterial = this.keep(new T.LineBasicMaterial({ color: 0xc4a977, transparent: true, opacity: .22 }));
      [
        [[-.49, .98], [-.45, .78], [-.39, .59]],
        [[-.73, .64], [-.61, .49], [-.50, .36]],
        [[.48, 1.0], [.41, .82], [.37, .65]],
        [[.74, .60], [.62, .44], [.51, .31]],
        [[-.51, -.52], [-.51, -.84], [-.52, -1.12]],
        [[.44, -.59], [.46, -.88], [.53, -1.19]]
      ].forEach((points) => {
        const curve = new T.QuadraticBezierCurve3(...points.map(p => new T.Vector3(p[0], p[1], .050)));
        const geometry = this.keep(new T.BufferGeometry().setFromPoints(curve.getPoints(18)));
        this.model.add(new T.Line(geometry, lineMaterial));
      });

      const textureCanvas = document.createElement('canvas');
      textureCanvas.width = 128; textureCanvas.height = 128;
      const context = textureCanvas.getContext('2d');
      const gradient = context.createRadialGradient(64, 64, 3, 64, 64, 62);
      gradient.addColorStop(0, 'rgba(61,70,61,.22)');
      gradient.addColorStop(.45, 'rgba(61,70,61,.11)');
      gradient.addColorStop(1, 'rgba(61,70,61,0)');
      context.fillStyle = gradient; context.fillRect(0, 0, 128, 128);
      const shadowTexture = this.keep(new T.CanvasTexture(textureCanvas));
      const shadowMaterial = this.keep(new T.MeshBasicMaterial({ map: shadowTexture, transparent: true, depthWrite: false, opacity: .75 }));
      const shadowGeometry = this.keep(new T.PlaneGeometry(3.8, 1.8));
      const shadow = new T.Mesh(shadowGeometry, shadowMaterial);
      shadow.rotation.x = -Math.PI / 2;
      shadow.position.set(0, -1.90, -.12);
      this.scene.add(shadow);
    }

    setupFallback() {
      this.context = this.canvas.getContext('2d');
      if (!this.context) {
        this.fallbackCanvas = document.createElement('canvas');
        this.fallbackCanvas.setAttribute('aria-hidden', 'true');
        this.fallbackCanvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;pointer-events:none';
        if (global.getComputedStyle(this.canvas.parentElement).position === 'static') {
          this.originalParentPosition = this.canvas.parentElement.style.position;
          this.canvas.parentElement.style.position = 'relative';
        }
        this.canvas.parentElement.appendChild(this.fallbackCanvas);
        this.canvas.style.opacity = '0';
        this.context = this.fallbackCanvas.getContext('2d');
      }
      this.paths = [BODY, ENAMEL, DENTIN, PULP].map(commands => trace(new Path2D(), commands));
    }

    listen(target, name, listener, options) {
      target.addEventListener(name, listener, options);
      this.listeners.push(() => target.removeEventListener(name, listener, options));
    }

    bindEvents() {
      this.listen(this.canvas, 'pointerdown', event => {
        if (event.pointerType === 'mouse' && event.button !== 0) return;
        this.pointer = { id: event.pointerId, x: event.clientX, y: event.clientY };
        if (this.canvas.setPointerCapture) this.canvas.setPointerCapture(event.pointerId);
        this.canvas.style.cursor = 'grabbing';
      });
      this.listen(this.canvas, 'pointermove', event => {
        if (!this.pointer || event.pointerId !== this.pointer.id) return;
        this.yaw += (event.clientX - this.pointer.x) * .008;
        this.pitch = Math.max(-1.1, Math.min(1.1, this.pitch + (event.clientY - this.pointer.y) * .006));
        this.pointer.x = event.clientX;
        this.pointer.y = event.clientY;
        this.requestRender();
      });
      const stop = () => { this.pointer = null; this.canvas.style.cursor = 'grab'; };
      this.listen(this.canvas, 'pointerup', stop);
      this.listen(this.canvas, 'pointercancel', stop);
      this.listen(this.canvas, 'lostpointercapture', stop);
      this.listen(this.canvas, 'wheel', event => {
        // Page scrolling is preserved; use Ctrl / trackpad pinch to zoom.
        if (!event.ctrlKey) return;
        event.preventDefault();
        this.zoom = Math.max(.75, Math.min(1.35, this.zoom - event.deltaY * .002));
        this.requestRender();
      }, { passive: false });
      this.canvas.style.cursor = 'grab';
      this.listen(this.canvas, 'keydown', event => {
        const actions = {
          ArrowLeft: () => { this.yaw -= .15; },
          ArrowRight: () => { this.yaw += .15; },
          ArrowUp: () => { this.pitch = Math.max(-1.1, this.pitch - .12); },
          ArrowDown: () => { this.pitch = Math.min(1.1, this.pitch + .12); },
          Home: () => this.reset(),
          '+': () => { this.zoom = Math.min(1.35, this.zoom + .08); },
          '-': () => { this.zoom = Math.max(.75, this.zoom - .08); }
        };
        if (actions[event.key]) { event.preventDefault(); actions[event.key](); this.requestRender(); }
      });
      this.listen(this.canvas, 'webglcontextlost', event => {
        event.preventDefault();
        if (this.renderer) this.renderer.dispose();
        this.renderer = null;
        this.mode = '2d';
        if (!this.context) this.setupFallback();
        if (this.fallback) this.fallback.hidden = false;
        this.resize();
      });
      this.listen(this.canvas, 'webglcontextrestored', () => {
        if (this.fallback) this.fallback.hidden = this.mode === '3d';
        this.requestRender();
      });
    }

    resize() {
      if (this.destroyed) return;
      const bounds = this.canvas.getBoundingClientRect();
      this.width = Math.max(1, bounds.width || this.canvas.clientWidth || 400);
      this.height = Math.max(1, bounds.height || this.canvas.clientHeight || 440);
      const dpr = Math.min(global.devicePixelRatio || 1, 2);
      if (this.renderer) {
        this.renderer.setPixelRatio(dpr);
        this.renderer.setSize(this.width, this.height, false);
        this.camera.aspect = this.width / this.height;
        this.camera.updateProjectionMatrix();
      } else {
        const canvas = this.fallbackCanvas || this.canvas;
        canvas.width = Math.round(this.width * dpr);
        canvas.height = Math.round(this.height * dpr);
        if (this.fallbackCanvas) {
          canvas.style.left = this.canvas.offsetLeft + 'px';
          canvas.style.top = this.canvas.offsetTop + 'px';
          canvas.style.width = this.width + 'px';
          canvas.style.height = this.height + 'px';
        }
      }
      this.requestRender();
    }

    setPH(ph, threshold) {
      const value = Number(ph);
      this.ph = Number.isFinite(value) ? Math.max(0, Math.min(14, value)) : 7;
      const limit = Number(threshold);
      this.threshold = Number.isFinite(limit) ? Math.max(0, Math.min(14, limit)) : 5.5;
      this.acidic = this.ph < this.threshold;
      if (this.indicatorMaterial) {
        this.indicatorMaterial.color.setHex(this.acidic ? 0xd39068 : 0x7faaa1);
        this.indicatorMaterial.opacity = this.acidic ? .23 : .11;
      }
      this.requestRender();
    }

    requestRender() {
      if (this.destroyed || this.frame) return;
      this.frame = global.requestAnimationFrame(() => {
        this.frame = 0;
        if (this.destroyed) return;
        this.render();
      });
    }

    render() {
      if (this.renderer) {
        this.model.rotation.set(this.pitch, this.yaw, 0);
        // Keep the complete tooth visible in portrait as well as landscape cards.
        const fit = Math.min(1, this.camera.aspect / .79);
        this.model.scale.setScalar(this.zoom * fit);
        this.renderer.render(this.scene, this.camera);
      } else if (this.context) {
        this.render2D();
      }
    }

    render2D() {
      const context = this.context;
      const canvas = this.fallbackCanvas || this.canvas;
      const dpr = Math.min(global.devicePixelRatio || 1, 2);
      context.setTransform(1, 0, 0, 1, 0, 0);
      context.clearRect(0, 0, canvas.width, canvas.height);
      context.scale(dpr, dpr);
      const scale = Math.min(this.width / 3.25, this.height / 4.1) * this.zoom;
      context.translate(this.width / 2, this.height / 2 - scale * .03);
      context.save();
      context.translate(0, scale * 1.80);
      context.scale(scale * 1.16, scale * .16);
      const shadow = context.createRadialGradient(0, 0, 0, 0, 0, 1);
      shadow.addColorStop(0, 'rgba(61,70,61,.13)'); shadow.addColorStop(1, 'rgba(61,70,61,0)');
      context.fillStyle = shadow; context.fillRect(-1, -1, 2, 2); context.restore();
      context.scale(scale, -scale);
      context.rotate(Math.max(-.12, Math.min(.12, this.yaw * .12)));
      context.lineJoin = 'round'; context.lineWidth = .014;
      const colors = ['#d8c4a2', '#f6f1df', '#e7cfa1', '#c88280'];
      this.paths.forEach((path, i) => {
        context.fillStyle = colors[i]; context.fill(path);
        context.strokeStyle = i === 1 ? '#e1d9c5' : i === 3 ? '#b87575' : '#c8b18b';
        context.stroke(path);
      });
      context.save();
      context.strokeStyle = this.acidic ? 'rgba(211,144,104,.58)' : 'rgba(127,170,161,.32)';
      context.lineWidth = .034; context.stroke(this.paths[1]); context.restore();
    }

    reset() {
      this.yaw = -.30;
      this.pitch = -.06;
      this.zoom = 1;
      this.requestRender();
    }

    destroy() {
      if (this.destroyed) return;
      this.destroyed = true;
      if (this.frame) global.cancelAnimationFrame(this.frame);
      if (this.observer) this.observer.disconnect();
      this.listeners.forEach(remove => remove());
      this.resources.forEach(resource => resource.dispose());
      if (this.renderer) this.renderer.dispose();
      if (this.fallbackCanvas) this.fallbackCanvas.remove();
      this.canvas.style.touchAction = this.originalTouchAction;
      this.canvas.style.opacity = this.originalOpacity;
      if (this.originalParentPosition !== undefined) this.canvas.parentElement.style.position = this.originalParentPosition;
      this.canvas.style.cursor = '';
    }
  }

  global.EnamelViewer = EnamelViewer;
})(window);
